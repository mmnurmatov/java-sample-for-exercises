package Algoritmga_kirish;

import java.util.Scanner;

/**
 * Created by Maqsud-PC on 24.12.2015.
 */
public class algoritm6 {
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
        System.out.println("Massiv o'lchamini kiriting:");
        System.out.println("Piramidal massiv elemenlarini kiriting:");


    }
}
